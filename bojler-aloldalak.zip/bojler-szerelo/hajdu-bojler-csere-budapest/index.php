<?php
$phone      = '06 (70) 164-4000';
$phone_link = 'tel:+36701644000';
$wa_link    = 'https://wa.me/36701644000?text=Szia!+Hajd%C3%BA+bojler+szerel%C3%A9st+szeretn%C3%A9k.';
$email      = 'providomuszkft@gmail.com';
$base       = 'https://www.bojler-szerelo-budapest.hu';
?><!DOCTYPE html>
<html lang="hu">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Hajdú Bojler Javítás és Csere Budapest – Szakszerviz | Provi Domus Kft.</title>
<meta name="description" content="Hajdú bojler javítás és csere Budapesten. Hajdú Aquastic, Z Smart, Ideállo szerviz. Magyar gyártású bojler szakszervize – eredeti alkatrészek, garancia, 0-24, 1-2 óra kiszállás.">
<meta name="keywords" content="hajdú bojler javítás budapest, hajdú bojler csere budapest, hajdú aquastic szerviz, hajdú z smart szerviz, hajdú ideállo, hajdú bojler nem melegít">
<meta name="robots" content="index, follow">
<link rel="canonical" href="<?= $base ?>/hajdu-bojler-csere-budapest/">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": ["Plumber","HVACBusiness"],
      "@id": "<?= $base ?>/#business",
      "name": "Provi Domus Kft. – Hajdú Bojler Szerviz Budapest",
      "url": "<?= $base ?>/hajdu-bojler-csere-budapest/",
      "telephone": "+36701644000",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "Hamvas utca 7-9",
        "addressLocality": "Budapest",
        "postalCode": "1191",
        "addressCountry": "HU"
      },
      "areaServed": {"@type": "City", "name": "Budapest"},
      "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": "4.9",
        "reviewCount": "143",
        "bestRating": "5"
      }
    },
    {
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Mennyibe kerül a Hajdú bojler javítás Budapesten?",
          "acceptedAnswer": {"@type": "Answer", "text": "Hajdú bojler javítás ára: fűtőszál csere 12.000–22.000 Ft, termosztát csere 10.000–18.000 Ft, biztonsági szelep csere 8.000–14.000 Ft. Az ár tartalmazza a kiszállást és az eredeti Hajdú alkatrészt."}
        },
        {
          "@type": "Question",
          "name": "Hol gyártják a Hajdú bojlereket?",
          "acceptedAnswer": {"@type": "Answer", "text": "A Hajdú bojlereket Debrecenben gyártják – ez egy 100%-ban magyar gyártású termék. A Hajdú Hajdúsági Rt. cég 1952 óta gyárt villanybojlereket. Az alkatrészek elérhetők és viszonylag olcsók."}
        }
      ]
    },
    {
      "@type": "BreadcrumbList",
      "itemListElement": [
        {"@type": "ListItem", "position": 1, "name": "Főoldal", "item": "<?= $base ?>/"},
        {"@type": "ListItem", "position": 2, "name": "Hajdú Bojler Szerviz Budapest", "item": "<?= $base ?>/hajdu-bojler-csere-budapest/"}
      ]
    }
  ]
}
</script>

<style>
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;background:#0a0a0a;color:#f0f0f0;line-height:1.6}
a{color:#ff6b00;text-decoration:none}
a:hover{text-decoration:underline}
.site-header{background:#111;border-bottom:2px solid #c62828;position:sticky;top:0;z-index:100;padding:12px 20px}
.header-inner{max-width:1200px;margin:0 auto;display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap}
.logo a{color:#fff;font-size:1.2rem;font-weight:700;text-decoration:none}
.logo span{color:#ff6b00}
.header-phone a{background:#c62828;color:#fff;padding:9px 20px;border-radius:5px;font-weight:700;font-size:1rem;text-decoration:none}
nav{display:flex;gap:6px;flex-wrap:wrap}
nav a{color:#ccc;font-size:.82rem;padding:4px 8px;border-radius:3px;text-decoration:none}
nav a:hover{color:#ff6b00}
nav a.active{color:#ff6b00;font-weight:700}
.urgency-bar{background:linear-gradient(90deg,#e65100,#f57c00);text-align:center;padding:10px;font-weight:700;font-size:.95rem}
.urgency-bar a{color:#fff;text-decoration:none}
.hero{background:linear-gradient(135deg,#1a0800,#2a1200,#1a0800);padding:60px 20px;border-bottom:3px solid #e65100}
.hero-inner{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:1fr 380px;gap:40px;align-items:start}
.hero-badge{display:inline-block;background:#e65100;color:#fff;font-size:.8rem;font-weight:700;padding:4px 12px;border-radius:20px;margin-bottom:15px;text-transform:uppercase}
.hero h1{font-size:2.5rem;line-height:1.2;color:#fff;margin-bottom:16px}
.hero h1 span{color:#ffa726}
.hero-sub{font-size:1.1rem;color:#ccc;margin-bottom:25px}
.hero-ctas{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:30px}
.btn-primary{background:#c62828;color:#fff;padding:16px 32px;border-radius:6px;font-size:1.1rem;font-weight:700;text-decoration:none}
.btn-primary:hover{background:#e53935;text-decoration:none}
.btn-orange{background:#e65100;color:#fff;padding:14px 28px;border-radius:6px;font-size:1rem;font-weight:700;text-decoration:none}
.btn-orange:hover{background:#f57c00;text-decoration:none}
.hero-trust{display:flex;gap:20px;flex-wrap:wrap}
.trust-badge{display:flex;align-items:center;gap:8px;color:#ccc;font-size:.9rem}
.emergency-card{background:#1a0800;border:2px solid #e65100;border-radius:10px;padding:25px;text-align:center}
.emergency-card h3{color:#ffa726;font-size:1.2rem;margin-bottom:15px}
.big-phone{font-size:1.6rem;font-weight:700;color:#fff;display:block;margin-bottom:8px}
.big-phone a{color:#fff;text-decoration:none}
.emrg-btns{display:flex;flex-direction:column;gap:8px;margin-top:15px}
.emrg-btn{display:block;padding:11px;border-radius:5px;font-weight:700;text-decoration:none;font-size:.95rem;text-align:center}
.emrg-btn.phone{background:#c62828;color:#fff}
.emrg-btn.orange{background:#e65100;color:#fff}
.emrg-btn.wa{background:#25d366;color:#fff}
.emrg-btn:hover{opacity:.9;text-decoration:none}
.ai-snippet{background:linear-gradient(135deg,#1a0800,#001a0d);border:1px solid #e65100;border-left:4px solid #ffa726;border-radius:8px;padding:20px 25px;margin:40px auto;max-width:1200px}
.ai-snippet-label{font-size:.75rem;color:#ffa726;text-transform:uppercase;letter-spacing:1.5px;font-weight:700;margin-bottom:8px}
.ai-snippet p{color:#ddd;font-size:1rem;line-height:1.7}
.section{padding:60px 20px}
.section-inner{max-width:1200px;margin:0 auto}
.section-title{font-size:2rem;color:#fff;margin-bottom:10px;text-align:center}
.section-title span{color:#ffa726}
.section-sub{text-align:center;color:#999;margin-bottom:40px}
.model-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}
.model-card{background:#141414;border:1px solid #2a1a00;border-radius:10px;overflow:hidden;transition:.2s}
.model-card:hover{border-color:#e65100;transform:translateY(-3px)}
.model-head{background:linear-gradient(135deg,#1a0800,#2a1400);padding:20px;border-bottom:1px solid #2a1a00}
.model-head h3{color:#fff;font-size:1.05rem;margin-bottom:4px}
.model-head .model-sub{color:#ffa726;font-size:.82rem}
.model-head .hu-badge{display:inline-block;background:#e65100;color:#fff;font-size:.72rem;padding:2px 8px;border-radius:10px;margin-top:5px}
.model-body{padding:18px}
.spec-row{display:flex;justify-content:space-between;padding:5px 0;border-bottom:1px solid #1a1a1a;font-size:.85rem}
.spec-row:last-child{border-bottom:none}
.spec-row .label{color:#777}
.spec-row .val{color:#ccc}
.model-price{background:#0d1100;padding:12px 18px;display:flex;justify-content:space-between;align-items:center}
.model-price .from{color:#777;font-size:.8rem}
.model-price .amount{color:#f57f17;font-size:1.1rem;font-weight:700}
.model-card a.link{display:block;text-align:center;padding:10px;background:rgba(230,81,0,.1);border-top:1px solid #2a1a00;color:#ffa726;font-size:.85rem;font-weight:600;text-decoration:none}
.model-card a.link:hover{background:rgba(230,81,0,.2)}
.price-table{width:100%;border-collapse:collapse;margin-bottom:20px}
.price-table th{background:#e65100;color:#fff;padding:12px 16px;text-align:left}
.price-table td{padding:12px 16px;border-bottom:1px solid #1a1a1a;color:#ccc;font-size:.9rem}
.price-table tr:nth-child(even) td{background:#111}
.price-col{color:#f57f17;font-weight:700}
.symptoms-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px}
.symptom-card{background:#141414;border:1px solid #2a1a00;border-radius:10px;padding:22px}
.symptom-icon{font-size:2rem;margin-bottom:10px}
.symptom-card h3{color:#ffa726;font-size:1rem;margin-bottom:8px}
.symptom-card p{color:#bbb;font-size:.88rem;margin-bottom:8px}
.symptom-price{color:#f57f17;font-size:.9rem;font-weight:700}
.faq-list{display:flex;flex-direction:column;gap:12px}
.faq-item{background:#141414;border:1px solid #1a1a1a;border-radius:8px;overflow:hidden}
.faq-q{padding:16px 20px;cursor:pointer;color:#fff;font-size:1rem;font-weight:600;display:flex;justify-content:space-between;align-items:center}
.faq-q::after{content:'▼';font-size:.75rem;color:#ffa726}
.faq-item.open .faq-q::after{transform:rotate(180deg)}
.faq-a{display:none;padding:0 20px 16px;color:#bbb;font-size:.9rem;line-height:1.7}
.faq-item.open .faq-a{display:block}
.related-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px}
.related-link{background:#141414;border:1px solid #1a1a1a;border-radius:8px;padding:14px 18px;display:flex;align-items:center;gap:10px;color:#ccc;text-decoration:none;font-size:.9rem;transition:.2s}
.related-link:hover{border-color:#ffa726;color:#ffa726;text-decoration:none}
.cta-banner{background:linear-gradient(135deg,#c62828,#b71c1c);padding:50px 20px;text-align:center}
.cta-banner h2{color:#fff;font-size:2rem;margin-bottom:10px}
.cta-banner p{color:#ffcccc;margin-bottom:25px}
.cta-banner .btn-white{background:#fff;color:#c62828;padding:16px 36px;border-radius:6px;font-size:1.1rem;font-weight:700;text-decoration:none;display:inline-block}
.site-footer{background:#0a0a0a;border-top:1px solid #1a1a1a;padding:40px 20px;color:#666;font-size:.85rem}
.footer-inner{max-width:1200px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:30px}
.footer-col h4{color:#ccc;margin-bottom:12px}
.footer-col a{display:block;color:#666;margin-bottom:6px;text-decoration:none}
.footer-col a:hover{color:#ff6b00}
.footer-bottom{max-width:1200px;margin:20px auto 0;padding-top:20px;border-top:1px solid #1a1a1a;display:flex;justify-content:space-between;flex-wrap:wrap;gap:10px;color:#555;font-size:.8rem}
.float-btns{position:fixed;bottom:24px;right:20px;display:flex;flex-direction:column;gap:10px;z-index:1000}
.float-btn{width:54px;height:54px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.5rem;box-shadow:0 4px 15px rgba(0,0,0,.5);text-decoration:none}
.float-btn.phone{background:#c62828;color:#fff;animation:pulse 2s infinite}
.float-btn.wa{background:#25d366;color:#fff}
.float-btn:hover{transform:scale(1.1);text-decoration:none}
@keyframes pulse{0%,100%{box-shadow:0 4px 15px rgba(198,40,40,.5)}50%{box-shadow:0 4px 25px rgba(198,40,40,.9),0 0 0 8px rgba(198,40,40,.2)}}
@media(max-width:768px){.hero-inner{grid-template-columns:1fr}.hero h1{font-size:1.7rem}}
</style>
</head>
<body>

<div class="float-btns">
  <a href="<?= $phone_link ?>" class="float-btn phone">📞</a>
  <a href="<?= $wa_link ?>" class="float-btn wa" target="_blank">💬</a>
</div>

<header class="site-header">
  <div class="header-inner">
    <div class="logo"><a href="<?= $base ?>/"><span>🔥</span> Bojler Szerelő Budapest</a></div>
    <nav>
      <a href="<?= $base ?>/">Főoldal</a>
      <a href="<?= $base ?>/bojler-javitas-budapest/">Javítás</a>
      <a href="<?= $base ?>/bojler-csere-budapest/">Csere</a>
      <a href="<?= $base ?>/bojler-vizkotelenites-budapest/">Vízkőtelenítés</a>
      <a href="<?= $base ?>/ariston-bojler-javitas-budapest/">Ariston</a>
      <a href="<?= $base ?>/hajdu-bojler-csere-budapest/" class="active">Hajdú</a>
    </nav>
    <div class="header-phone"><a href="<?= $phone_link ?>"><?= $phone ?></a></div>
  </div>
</header>

<div class="urgency-bar">
  🟠 HAJDÚ BOJLER SZERVIZ BUDAPEST – MAGYAR SZAKSZERVIZ – EREDETI ALKATRÉSZEK →
  <a href="<?= $phone_link ?>"><?= $phone ?></a>
</div>

<section class="hero">
  <div class="hero-inner">
    <div>
      <span class="hero-badge">🟠 Hajdú Szakszerviz Budapest</span>
      <h1>Hajdú Bojler Javítás<br><span>és Csere Budapesten</span></h1>
      <p class="hero-sub">Hajdú Aquastic nem melegít? Z Smart nem reagál? Ideállo csöpög? Hajdú szakszervizként ismerjük minden Hajdú model sajátosságát és rendelkezünk az eredeti Hajdú alkatrészekkel. Debrecenből Budapest – a legjobb magyar bojler megérdemli a legjobb szervizt!</p>
      <div class="hero-ctas">
        <a href="<?= $phone_link ?>" class="btn-primary">📞 Hívjon Most – <?= $phone ?></a>
        <a href="<?= $wa_link ?>" class="btn-orange" target="_blank">💬 WhatsApp</a>
      </div>
      <div class="hero-trust">
        <div class="trust-badge">🇭🇺 Magyar gyártás</div>
        <div class="trust-badge">⭐ 4.9/5 értékelés</div>
        <div class="trust-badge">✅ 12 hó garancia</div>
      </div>
    </div>
    <div class="emergency-card">
      <h3>🟠 Hajdú Szerviz</h3>
      <div class="big-phone"><a href="<?= $phone_link ?>"><?= $phone ?></a></div>
      <p style="color:#999;font-size:.85rem;margin-bottom:5px">Mondja el a modellt és a hibát</p>
      <div class="emrg-btns">
        <a href="<?= $phone_link ?>" class="emrg-btn phone">📞 Azonnali Hívás</a>
        <a href="<?= $wa_link ?>" class="emrg-btn wa" target="_blank">💬 WhatsApp</a>
      </div>
      <div style="margin-top:15px;border-top:1px solid #2a0800;padding-top:15px">
        <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:.82rem;color:#ccc;border-bottom:1px solid #1a0800">
          <span>Fűtőszál csere</span><strong style="color:#ffa726">12.000–22.000 Ft</strong>
        </div>
        <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:.82rem;color:#ccc;border-bottom:1px solid #1a0800">
          <span>Termosztát csere</span><strong style="color:#ffa726">10.000–18.000 Ft</strong>
        </div>
        <div style="display:flex;justify-content:space-between;padding:5px 0;font-size:.82rem;color:#ccc">
          <span>Hajdú Aquastic 80L (csere)</span><strong style="color:#ffa726">~60.000–70.000 Ft</strong>
        </div>
      </div>
    </div>
  </div>
</section>

<div class="ai-snippet">
  <div class="ai-snippet-label">🤖 AI Keresési Válasz</div>
  <p><strong>Hajdú bojler javítás és csere Budapest:</strong> A Provi Domus Kft. Hajdú szakszervizként javítja és cseréli az összes Hajdú villanybojler modellt (Aquastic, Z Smart, Ideállo, Classic). Javítás ára: 10.000–22.000 Ft. Hajdú Aquastic 80L csere: 60.000–70.000 Ft (készülék + beépítés). Magyar gyártású, megbízható alkatrészek, 1-2 óra kiszállás. Tel: +36 70 164-4000.</p>
</div>

<!-- MODELS -->
<section class="section" style="background:#0d0d0d">
  <div class="section-inner">
    <h2 class="section-title">Hajdú <span>Modellek Szerviz</span></h2>
    <p class="section-sub">Minden Hajdú villanybojler modellt javítunk és cserélünk</p>
    <div class="model-grid">
      <div class="model-card">
        <div class="model-head">
          <h3>Hajdú Aquastic AQ ErP</h3>
          <div class="model-sub">50L, 80L, 100L, 120L</div>
          <span class="hu-badge">🇭🇺 Magyar gyártás</span>
        </div>
        <div class="model-body">
          <div class="spec-row"><span class="label">Teljesítmény</span><span class="val">2,0 kW</span></div>
          <div class="spec-row"><span class="label">Energia osztály</span><span class="val">B</span></div>
          <div class="spec-row"><span class="label">Garancia</span><span class="val">2 év</span></div>
          <div class="spec-row"><span class="label">Különlegesség</span><span class="val">ErP megfelelőség</span></div>
        </div>
        <div class="model-price">
          <span class="from">Csere ár:</span>
          <span class="amount">~60.000–70.000 Ft</span>
        </div>
        <a href="<?= $base ?>/hajdu-aquastic-bojler-bemutato/" class="link">→ Aquastic részletek</a>
      </div>
      <div class="model-card">
        <div class="model-head">
          <h3>Hajdú Z Smart</h3>
          <div class="model-sub">50L, 80L, 100L</div>
          <span class="hu-badge">🇭🇺 WiFi vezérlés</span>
        </div>
        <div class="model-body">
          <div class="spec-row"><span class="label">Teljesítmény</span><span class="val">2,0 kW</span></div>
          <div class="spec-row"><span class="label">Energia osztály</span><span class="val">A</span></div>
          <div class="spec-row"><span class="label">Garancia</span><span class="val">3 év</span></div>
          <div class="spec-row"><span class="label">App</span><span class="val">Hajdú Smart</span></div>
        </div>
        <div class="model-price">
          <span class="from">Csere ár:</span>
          <span class="amount">~80.000–90.000 Ft</span>
        </div>
        <a href="<?= $base ?>/hajdu-z-smart-bojler-bemutato/" class="link">→ Z Smart részletek</a>
      </div>
      <div class="model-card">
        <div class="model-head">
          <h3>Hajdú Ideállo</h3>
          <div class="model-sub">50L, 75L, 100L, 150L</div>
          <span class="hu-badge">🇭🇺 Nagy kapacitás</span>
        </div>
        <div class="model-body">
          <div class="spec-row"><span class="label">Teljesítmény</span><span class="val">2,0–3,0 kW</span></div>
          <div class="spec-row"><span class="label">Energia osztály</span><span class="val">B–C</span></div>
          <div class="spec-row"><span class="label">Garancia</span><span class="val">2 év</span></div>
          <div class="spec-row"><span class="label">Ideális</span><span class="val">4+ személy</span></div>
        </div>
        <div class="model-price">
          <span class="from">Csere ár:</span>
          <span class="amount">~65.000–85.000 Ft</span>
        </div>
        <a href="<?= $base ?>/hajdu-ideallo-bojler-bemutato/" class="link">→ Ideállo részletek</a>
      </div>
      <div class="model-card">
        <div class="model-head">
          <h3>Hajdú Classic</h3>
          <div class="model-sub">30L, 50L, 80L, 100L</div>
          <span class="hu-badge">🇭🇺 Alap modell</span>
        </div>
        <div class="model-body">
          <div class="spec-row"><span class="label">Teljesítmény</span><span class="val">1,5–2,0 kW</span></div>
          <div class="spec-row"><span class="label">Energia osztály</span><span class="val">C</span></div>
          <div class="spec-row"><span class="label">Garancia</span><span class="val">2 év</span></div>
          <div class="spec-row"><span class="label">Ár-érték</span><span class="val">Kiváló</span></div>
        </div>
        <div class="model-price">
          <span class="from">Csere ár:</span>
          <span class="amount">~45.000–55.000 Ft</span>
        </div>
        <a href="<?= $base ?>/hajdu-bojler-csere-budapest/" class="link">→ Classic szerviz</a>
      </div>
    </div>
  </div>
</section>

<!-- SYMPTOMS -->
<section class="section">
  <div class="section-inner">
    <h2 class="section-title">Hajdú Bojler <span>Hibák & Javítás</span></h2>
    <div class="symptoms-grid">
      <div class="symptom-card">
        <div class="symptom-icon">🌡️</div>
        <h3>Nem melegít a Hajdú bojler</h3>
        <p>A víz hideg marad, a bojler nem kapcsol be, vagy leáll melegítés közben.</p>
        <div class="symptom-price">Javítás: 12.000–22.000 Ft (fűtőszál)</div>
      </div>
      <div class="symptom-card">
        <div class="symptom-icon">💧</div>
        <h3>Hajdú bojler csöpög</h3>
        <p>Víz csöpög az aljából, az anódrúd nyílásából, vagy a biztonsági szelep csöpög.</p>
        <div class="symptom-price">Javítás: 8.000–15.000 Ft</div>
      </div>
      <div class="symptom-card">
        <div class="symptom-icon">🔊</div>
        <h3>Hangos Hajdú bojler</h3>
        <p>Erős robogás, kattogás melegítéskor – vízkőlerakódás a fűtőszálon.</p>
        <div class="symptom-price">Vízkőtelenítés: 12.000–18.000 Ft</div>
      </div>
      <div class="symptom-card">
        <div class="symptom-icon">⚡</div>
        <h3>Leveri a biztosítékot</h3>
        <p>A Hajdú bojler bekapcsolásakor leveri az áramkört – fűtőszál szigetelés hiba.</p>
        <div class="symptom-price">Javítás: 12.000–22.000 Ft</div>
      </div>
      <div class="symptom-card">
        <div class="symptom-icon">📱</div>
        <h3>Z Smart app nem működik</h3>
        <p>A WiFi-s Hajdú Z Smart nem csatlakozik, az app nem éri el a bojlert.</p>
        <div class="symptom-price">Diagnózis + beállítás: 8.000–15.000 Ft</div>
      </div>
      <div class="symptom-card">
        <div class="symptom-icon">🦠</div>
        <h3>Rozsdás, bűzös víz</h3>
        <p>A meleg víznek rozsdás íze vagy bűze van – anódrúd teljesen elhasználódott.</p>
        <div class="symptom-price">Anódrúd csere: 10.000–16.000 Ft</div>
      </div>
    </div>
  </div>
</section>

<!-- PRICES -->
<section class="section" style="background:#0d0d0d">
  <div class="section-inner">
    <h2 class="section-title">Hajdú Javítás <span>Árak 2025</span></h2>
    <table class="price-table">
      <thead>
        <tr><th>Javítás</th><th>Hajdú modell</th><th class="price-col">Ár (Ft)</th><th>Idő</th></tr>
      </thead>
      <tbody>
        <tr><td><strong>Fűtőszál csere</strong></td><td>Aquastic, Z Smart, Ideállo, Classic</td><td class="price-col">12.000–22.000</td><td>2-3 óra</td></tr>
        <tr><td><strong>Termosztát csere</strong></td><td>Minden modell</td><td class="price-col">10.000–18.000</td><td>1-2 óra</td></tr>
        <tr><td><strong>Biztonsági szelep</strong></td><td>Minden modell</td><td class="price-col">8.000–14.000</td><td>1 óra</td></tr>
        <tr><td><strong>Anódrúd csere</strong></td><td>Minden modell</td><td class="price-col">10.000–16.000</td><td>1-2 óra</td></tr>
        <tr><td><strong>WiFi modul beállítás</strong></td><td>Z Smart</td><td class="price-col">8.000–15.000</td><td>1 óra</td></tr>
        <tr><td><strong>Teljes csere (Aquastic 80L)</strong></td><td>Aquastic</td><td class="price-col">60.000–70.000</td><td>2-3 óra</td></tr>
      </tbody>
    </table>
  </div>
</section>

<!-- FAQ -->
<section class="section">
  <div class="section-inner">
    <h2 class="section-title">Hajdú Szerviz <span>GYIK</span></h2>
    <div class="faq-list">
      <div class="faq-item">
        <div class="faq-q">Hol gyártják a Hajdú bojlereket?</div>
        <div class="faq-a">A Hajdú bojlereket Debrecenben gyártják – a Hajdúsági Ipari Rt. 1952 óta gyárt villanybojlereket Magyarországon. Ez egy 100%-ban hazai termék, amelynek alkatrészei könnyen beszerezhetők és viszonylag olcsók. A Hajdú bojlerek kiváló ár-érték arányt képviselnek.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q">Melyik jobb – Hajdú vagy Ariston bojler?</div>
        <div class="faq-a">Mindkét márka megbízható. A Hajdú bojlerek általában olcsóbbak és az alkatrészek is könnyebben elérhetők. Az Ariston bojlerek prémiumabb hőszigetelést kínálnak és egyes modellek WiFi-s vezérlést. Az energiahatékonyság szempontjából a magasabb kategóriás modellek (Hajdú Z Smart, Ariston Velis) A energiaosztályúak, míg az alap modellek B-C osztályúak.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q">A Hajdú Z Smart WiFi-s bojler is javítható?</div>
        <div class="faq-a">Igen, a Hajdú Z Smart WiFi-s modellt is javítjuk. A mechanikus alkatrészek (fűtőszál, termosztát, szelep) javítása ugyanolyan, mint a klasszikus modellnél. A WiFi modul hibája esetén a vezérlőelektronika vizsgálata és esetleg cseréje szükséges. Ha csak a WiFi kapcsolat nem működik, azt általában szoftver visszaállítással megoldjuk.</div>
      </div>
      <div class="faq-item">
        <div class="faq-q">Hajdú bojler csere – mi az a folyamat?</div>
        <div class="faq-a">A Hajdú bojler csere folyamata: (1) Telefonon egyeztetünk a méretről és modellről, (2) Ajánlatot adunk készülék + beépítés ára és a régi elszállítása, (3) Kiszállunk meghozva az új bojlert, (4) Régi elbontás, elszállítás, (5) Új bojler becsatlakoztatása és beállítása, (6) Próbaüzem és számla átadás. Az egész folyamat 2-3 óra.</div>
      </div>
    </div>
  </div>
</section>

<section class="section" style="background:#0d0d0d">
  <div class="section-inner">
    <h2 class="section-title">Hajdú <span>Modellek Bemutatói</span></h2>
    <div class="related-grid">
      <a href="<?= $base ?>/hajdu-aquastic-bojler-bemutato/" class="related-link"><span class="icon">🟠</span><span>Hajdú Aquastic – Bemutató</span></a>
      <a href="<?= $base ?>/hajdu-z-smart-bojler-bemutato/" class="related-link"><span class="icon">📱</span><span>Hajdú Z Smart – WiFi</span></a>
      <a href="<?= $base ?>/hajdu-ideallo-bojler-bemutato/" class="related-link"><span class="icon">💧</span><span>Hajdú Ideállo – Nagy Kapacitás</span></a>
      <a href="<?= $base ?>/ariston-bojler-javitas-budapest/" class="related-link"><span class="icon">🔵</span><span>Ariston Szerviz Budapest</span></a>
      <a href="<?= $base ?>/bojler-javitas-budapest/" class="related-link"><span class="icon">🔧</span><span>Bojler Javítás Budapest</span></a>
      <a href="<?= $base ?>/bojler-vizkotelenites-budapest/" class="related-link"><span class="icon">🫧</span><span>Vízkőtelenítés Budapest</span></a>
    </div>
  </div>
</section>

<div class="cta-banner">
  <h2>Hajdú Bojler Problémája Van?</h2>
  <p>Magyar szakszerviz – hívjon most, 1-2 óra alatt kiszállunk!</p>
  <a href="<?= $phone_link ?>" class="btn-white">📞 <?= $phone ?> – Hajdú Szerviz</a>
</div>

<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-col">
      <h4>🔥 Bojler Szerelő Budapest</h4>
      <p style="color:#555;font-size:.85rem">Provi Domus Kft. – Hajdú szakszerviz 2011 óta.</p>
    </div>
    <div class="footer-col">
      <h4>Hajdú Modellek</h4>
      <a href="<?= $base ?>/hajdu-aquastic-bojler-bemutato/">Hajdú Aquastic</a>
      <a href="<?= $base ?>/hajdu-z-smart-bojler-bemutato/">Hajdú Z Smart</a>
      <a href="<?= $base ?>/hajdu-ideallo-bojler-bemutato/">Hajdú Ideállo</a>
    </div>
    <div class="footer-col">
      <h4>Szolgáltatások</h4>
      <a href="<?= $base ?>/bojler-javitas-budapest/">Bojler Javítás</a>
      <a href="<?= $base ?>/bojler-csere-budapest/">Bojler Csere</a>
      <a href="<?= $base ?>/bojler-vizkotelenites-budapest/">Vízkőtelenítés</a>
      <a href="<?= $base ?>/ariston-bojler-javitas-budapest/">Ariston Szerviz</a>
    </div>
    <div class="footer-col">
      <h4>Kerületek</h4>
      <a href="<?= $base ?>/bojler-szerelo-1-kerulet/">I. kerület</a>
      <a href="<?= $base ?>/bojler-szerelo-11-kerulet/">XI. kerület</a>
      <a href="<?= $base ?>/">→ Mind a 23 kerület</a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>© 2025 Provi Domus Kft. – Hajdú Bojler Szerviz Budapest.</span>
    <span>📞 <a href="<?= $phone_link ?>" style="color:#ff6b00"><?= $phone ?></a></span>
  </div>
</footer>

<script>
document.querySelectorAll('.faq-q').forEach(q => {
  q.addEventListener('click', () => q.parentElement.classList.toggle('open'));
});
</script>
</body>
</html>
